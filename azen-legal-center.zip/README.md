# Azen Legal Center

Static GitHub Pages-ready Terms of Service and Privacy Policy website for Azen.

## Files

- `index.html` — legal center landing page
- `terms.html` — Terms of Service
- `privacy.html` — Privacy Policy
- `style.css` — shared UI

## Before publishing

Replace:

- `YOUR_EMAIL@example.com` with your real support/privacy email
- The data categories in `privacy.html` with the exact data Azen actually stores
- The storage/provider section with your real database, hosting and logging providers
- Retention periods with your actual retention/deletion behavior
- The effective date if needed

This is a general template and should be reviewed for your actual implementation and applicable laws before publication.
